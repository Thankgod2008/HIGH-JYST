-- HIGH JYST starter schema for Supabase Postgres.
-- Run in Supabase SQL Editor after creating a project.
create extension if not exists pgcrypto;

create type public.friendship_status as enum ('pending', 'accepted', 'declined', 'blocked');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  cover_url text,
  bio text check (char_length(bio) <= 500),
  location text,
  is_private boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint username_format check (username is null or username ~ '^[a-zA-Z0-9_]{3,24}$')
);

create table public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text check (char_length(content) <= 5000),
  media_url text,
  media_type text check (media_type is null or media_type in ('image','video')),
  visibility text not null default 'public' check (visibility in ('public','friends','private')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint post_has_content_or_media check (nullif(trim(content), '') is not null or media_url is not null)
);

create table public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status public.friendship_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint no_self_friendship check (requester_id <> addressee_id),
  constraint unique_friendship_pair unique (requester_id, addressee_id)
);

create table public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text check (body is null or char_length(body) <= 5000),
  media_url text,
  media_type text check (media_type is null or media_type = 'image'),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  constraint message_has_content_or_media check (nullif(trim(body), '') is not null or media_url is not null)
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  kind text not null check (kind in ('friend_request','friend_accepted','like','comment','message')),
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index posts_created_at_idx on public.posts(created_at desc);
create index posts_user_id_idx on public.posts(user_id, created_at desc);
create index friendships_addressee_idx on public.friendships(addressee_id, status);
create index messages_conversation_idx on public.messages(conversation_id, created_at desc);
create index notifications_recipient_idx on public.notifications(recipient_id, created_at desc);

-- Create a profile for each new auth user. Username is intentionally null until chosen in profile setup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Enable RLS everywhere.
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.friendships enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;

-- Profiles: public profile discovery; only owners may edit their profile.
create policy "Profiles are viewable" on public.profiles for select to anon, authenticated using (true);
create policy "Users create their own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Public posts are visible to everyone; friends/private visibility needs server-side friend-aware policies before launch.
create policy "Public posts are viewable" on public.posts for select to anon, authenticated using (visibility = 'public' or user_id = auth.uid());
create policy "Users create own posts" on public.posts for insert to authenticated with check (auth.uid() = user_id);
create policy "Owners update own posts" on public.posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Owners delete own posts" on public.posts for delete to authenticated using (auth.uid() = user_id);

create policy "Friendship participants can view" on public.friendships for select to authenticated using (auth.uid() = requester_id or auth.uid() = addressee_id);
create policy "Users send requests as themselves" on public.friendships for insert to authenticated with check (auth.uid() = requester_id and status = 'pending');
create policy "Participants update requests" on public.friendships for update to authenticated using (auth.uid() = requester_id or auth.uid() = addressee_id) with check (auth.uid() = requester_id or auth.uid() = addressee_id);
create policy "Participants delete friendship" on public.friendships for delete to authenticated using (auth.uid() = requester_id or auth.uid() = addressee_id);

create policy "Likes visible to everyone" on public.likes for select to anon, authenticated using (true);
create policy "Users like as themselves" on public.likes for insert to authenticated with check (auth.uid() = user_id);
create policy "Users remove own likes" on public.likes for delete to authenticated using (auth.uid() = user_id);

create policy "Comments visible to everyone" on public.comments for select to anon, authenticated using (true);
create policy "Users comment as themselves" on public.comments for insert to authenticated with check (auth.uid() = user_id);
create policy "Users delete own comments" on public.comments for delete to authenticated using (auth.uid() = user_id);

-- Conversation membership is the gatekeeper for message access.
create policy "Members view their conversations" on public.conversations for select to authenticated using (
  exists (select 1 from public.conversation_members cm where cm.conversation_id = id and cm.user_id = auth.uid())
);
create policy "Authenticated users create conversations" on public.conversations for insert to authenticated with check (true);
create policy "Members can view membership rows" on public.conversation_members for select to authenticated using (
  exists (select 1 from public.conversation_members cm where cm.conversation_id = conversation_id and cm.user_id = auth.uid())
);
create policy "Users add themselves as members" on public.conversation_members for insert to authenticated with check (auth.uid() = user_id);
create policy "Members view messages" on public.messages for select to authenticated using (
  exists (select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid())
);
create policy "Members send messages as themselves" on public.messages for insert to authenticated with check (
  auth.uid() = sender_id and exists (select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid())
);
create policy "Sender marks message read" on public.messages for update to authenticated using (
  exists (select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid())
);

create policy "Users view own notifications" on public.notifications for select to authenticated using (auth.uid() = recipient_id);
create policy "Users update own notifications" on public.notifications for update to authenticated using (auth.uid() = recipient_id) with check (auth.uid() = recipient_id);

-- Storage buckets: create in Storage UI with these IDs and public/private settings.
-- post-media: public bucket for public demo posts. For production private media, use a private bucket and signed URLs.
-- message-media: PRIVATE bucket; add policies limiting access to conversation participants before enabling message attachments.
