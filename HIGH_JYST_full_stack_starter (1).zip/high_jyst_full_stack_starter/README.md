# HIGH JYST — full-stack starter

This is a responsive Next.js + Supabase starter for the HIGH JYST global social network. It includes a luxury black-and-gold interface, email/password sign-up and login, public news-feed loading, text posts, image/video uploads, and basic reactions.

**Important:** this is a starter project, not a fully launched or production-audited social network. Friend-request workflows, profile editing, comments, notifications, and the messaging screens still need implementation. The database schema includes starter tables for those features, but tables alone do not make a feature complete.

## Requirements
- Node.js 20 or newer
- A Supabase account
- A deployment account such as Vercel

## 1. Create a Supabase project
1. Create a project at https://supabase.com.
2. Open **Project Settings → API** and copy the Project URL and `anon` / publishable key.
3. In the project, open **SQL Editor**, create a new query, paste `supabase/schema.sql`, and run it.
4. In **Authentication → URL Configuration**, set your local Site URL to `http://localhost:3000`. Add your production website URL after deployment.
5. In **Storage**, create a bucket named `post-media`. For this starter's public-feed display, mark it public. Set a reasonable file size limit and image/video MIME type restrictions.

### Storage upload policies
The SQL starter intentionally does not silently create permissive storage policies. In Supabase Storage → Policies, add policies for bucket `post-media`:
- Authenticated users may upload only into a folder matching their user ID (`(storage.foldername(name))[1] = auth.uid()::text`).
- Owners may delete only files under their own user-ID folder.
- Public read is allowed only if you accept that media in this bucket is public.
For private uploads or private messages, use a private bucket with short-lived signed URLs and policies checking conversation membership. Do not put secrets or service-role keys in browser code.

## 2. Configure the app
1. Install Node.js 20+ from https://nodejs.org.
2. Extract this ZIP.
3. Copy `.env.example` to `.env.local`.
4. Fill in `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
5. In a terminal, from the project folder run:

```bash
npm install
npm run dev
```

6. Open http://localhost:3000.

## 3. Email confirmation
Supabase may require email confirmation before a new account can sign in. Configure SMTP for production rather than relying on test/default email delivery. Test sign-up, confirmation, sign-in, and sign-out.

## 4. Deploy to Vercel
1. Push the project to a private GitHub repository.
2. Import it into https://vercel.com.
3. Add the two environment variables from `.env.local` in Vercel Project Settings → Environment Variables.
4. Deploy.
5. Add the final Vercel domain to Supabase Authentication URL Configuration and allowed redirect URLs.
6. Test on mobile and desktop.

## Implemented in this starter
- Responsive dark / gold home and feed UI
- Supabase email/password sign-up and sign-in form
- Supabase auth session check and sign-out
- New-user profile row created by a database trigger
- Feed reads public posts from Supabase
- Create text posts and upload image/video attachments
- Basic “Appreciate” reaction stored in the likes table
- Search through loaded post text and author names
- Basic real-time refresh when the posts table changes
- Row Level Security starter policies in the SQL file

## Not yet implemented / needs more work
- Friend search, sending/accepting/rejecting requests, and friend-only feed logic
- Profile settings UI, avatar/cover uploads, username editing, password reset
- Comments and threaded replies
- Direct messaging UI, conversation creation, unread state, photo attachments
- Notification generation and notification centre
- Privacy controls UI and fully tested friend-only/private post policies
- Reporting, blocking, moderation queue, spam/rate limits, abuse handling
- Email templates, production SMTP, CAPTCHA / anti-bot controls, backups and monitoring
- Automated tests, accessibility audit, security review, upload scanning/video processing

## Security checklist before public launch
- Review and test every RLS policy with separate test accounts.
- Do not enable private posts until policies explicitly check accepted friendships.
- Add strict server-side validation and rate limiting for posts, uploads, friend requests, messages, and auth.
- Keep service-role keys server-side only.
- Prefer private storage and signed URLs for non-public media.
- Implement block/report tools, moderation, account deletion, and data export.
- Configure production SMTP, CAPTCHA/abuse prevention, logs, backups, and incident response.
- Publish Terms of Service, Privacy Policy, Community Guidelines, and an age policy.
- Get a professional security review before collecting meaningful user data.

This starter deliberately shows clear notices for buttons/features that are not yet backed by real workflows rather than pretending those actions are complete.
