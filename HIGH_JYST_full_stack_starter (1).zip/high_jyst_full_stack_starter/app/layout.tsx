import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HIGH JYST — A Global Community",
  description: "Share your world. Find your people. Connect across borders."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}