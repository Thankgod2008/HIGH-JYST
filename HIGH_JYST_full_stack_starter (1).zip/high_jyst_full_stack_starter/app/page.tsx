 "use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Globe2, Home, Users, MessageCircle, Bell, Search, ImagePlus, Heart, MessageSquare, Send, ShieldCheck, LogOut, UserRound, Menu, X, LoaderCircle } from "lucide-react";

type Profile = { id: string; username: string | null; display_name: string | null; avatar_url: string | null; bio: string | null };
type Post = { id: string; content: string | null; media_url: string | null; media_type: string | null; created_at: string; profiles: Profile | null; likes?: { user_id: string }[]; comments?: { id: string }[] };

export default function HomePage() {
  const [supabase, setSupabase] = useState<ReturnType<typeof createClient> | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"signup" | "login">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [composer, setComposer] = useState("");
  const [upload, setUpload] = useState<File | null>(null);
  const [posting, setPosting] = useState(false);
  const [search, setSearch] = useState("");
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    try { setSupabase(createClient()); } catch (e) { setNotice((e as Error).message); setLoading(false); }
  }, []);

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
        if (alive) setProfile(data as Profile | null);
      }
      const { data, error } = await supabase.from("posts").select("id,content,media_url,media_type,created_at,profiles(id,username,display_name,avatar_url,bio)").order("created_at", { ascending: false }).limit(40);
      if (alive) {
        if (!error && data) setPosts(data as unknown as Post[]);
        setLoading(false);
      }
    };
    load();
    const channel = supabase.channel("high-jyst-post-feed").on("postgres_changes", { event: "*", schema: "public", table: "posts" }, () => load()).subscribe();
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [supabase]);

  async function handleAuth(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setAuthBusy(true); setNotice("");
    try {
      if (authMode === "signup") {
        const { error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
        if (error) throw error;
        setNotice("Account request submitted. Check your email to confirm your address, then log in.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
          setProfile(data as Profile | null);
        }
        setAuthOpen(false); setNotice("You're signed in.");
      }
    } catch (e) { setNotice((e as Error).message || "Authentication failed."); }
    finally { setAuthBusy(false); }
  }

  async function signOut() {
    if (!supabase) return;
    await supabase.auth.signOut(); setProfile(null); setNotice("You have signed out.");
  }

  async function publish(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase || !profile) { setNotice("Please log in to publish a post."); setAuthMode("login"); setAuthOpen(true); return; }
    if (!composer.trim() && !upload) return;
    setPosting(true); setNotice("");
    try {
      let mediaUrl: string | null = null, mediaType: string | null = null;
      if (upload) {
        if (upload.size > 50 * 1024 * 1024) throw new Error("Please choose a file smaller than 50 MB.");
        if (!["image/jpeg", "image/png", "image/webp", "image/gif", "video/mp4", "video/webm"].includes(upload.type)) throw new Error("Use a JPG, PNG, WEBP, GIF, MP4, or WEBM file.");
        const path = `${profile.id}/${crypto.randomUUID()}-${upload.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
        const { error: uploadError } = await supabase.storage.from("post-media").upload(path, upload, { upsert: false, contentType: upload.type });
        if (uploadError) throw uploadError;
        const { data } = supabase.storage.from("post-media").getPublicUrl(path);
        mediaUrl = data.publicUrl; mediaType = upload.type.startsWith("video/") ? "video" : "image";
      }
      const { error } = await supabase.from("posts").insert({ user_id: profile.id, content: composer.trim() || null, media_url: mediaUrl, media_type: mediaType });
      if (error) throw error;
      setComposer(""); setUpload(null); const fileInput = document.getElementById("media-upload") as HTMLInputElement | null; if (fileInput) fileInput.value = "";
      setNotice("Your post was published."); 
      const { data } = await supabase.from("posts").select("id,content,media_url,media_type,created_at,profiles(id,username,display_name,avatar_url,bio)").order("created_at", { ascending: false }).limit(40);
      if (data) setPosts(data as unknown as Post[]);
    } catch (e) { setNotice((e as Error).message || "Could not publish post."); }
    finally { setPosting(false); }
  }

  async function likePost(postId: string) {
    if (!supabase || !profile) { setNotice("Log in to react to posts."); setAuthMode("login"); setAuthOpen(true); return; }
    const { error } = await supabase.from("likes").upsert({ post_id: postId, user_id: profile.id }, { onConflict: "post_id,user_id", ignoreDuplicates: true });
    if (error) setNotice(error.message); else setNotice("Reaction added.");
  }

  const visiblePosts = posts.filter(p => `${p.content || ""} ${p.profiles?.display_name || ""} ${p.profiles?.username || ""}`.toLowerCase().includes(search.toLowerCase()));
  const initials = (name?: string | null) => (name || "HJ").trim().split(/\s+/).slice(0, 2).map(x => x[0]).join("").toUpperCase();
  const timeAgo = (value: string) => { const mins = Math.max(1, Math.floor((Date.now() - new Date(value).getTime()) / 60000)); return mins < 60 ? `${mins}m ago` : mins < 1440 ? `${Math.floor(mins / 60)}h ago` : `${Math.floor(mins / 1440)}d ago`; };

  return <main>
    <header className="topbar">
      <a className="brand" href="#"><span className="brandMark">H</span><span>HIGH JYST</span></a>
      <div className="topSearch"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search posts and people…"/></div>
      <nav className={mobileNav ? "navLinks open" : "navLinks"}>
        <a href="#feed"><Home size={17}/> <span>Home</span></a><a href="#people" onClick={e=>{e.preventDefault();setNotice("People discovery is next on the build roadmap.");}}><Users size={17}/> <span>Friends</span></a><a href="#messages" onClick={e=>{e.preventDefault();setNotice("Private messaging UI requires the next implementation step.");}}><MessageCircle size={17}/> <span>Messages</span></a><a href="#notifications" onClick={e=>{e.preventDefault();setNotice("Notifications will appear here once notification events are enabled.");}}><Bell size={17}/> <span>Alerts</span></a>
      </nav>
      {profile ? <button className="accountBtn" onClick={signOut}><span className="avatar">{initials(profile.display_name || profile.username)}</span><span className="accountName">{profile.display_name || profile.username || "Account"}</span><LogOut size={16}/></button> : <div className="authButtons"><button className="btn outline" onClick={()=>{setAuthMode("login");setAuthOpen(true)}}>Log In</button><button className="btn gold" onClick={()=>{setAuthMode("signup");setAuthOpen(true)}}>Join Now</button></div>}
      <button className="mobileMenu" onClick={()=>setMobileNav(!mobileNav)} aria-label="Toggle menu">{mobileNav?<X/>:<Menu/>}</button>
    </header>
    <section className="hero">
      <div className="heroOrb"><div className="orbLine l1"/><div className="orbLine l2"/><div className="orbDot d1"/><div className="orbDot d2"/><div className="orbDot d3"/></div>
      <div className="heroCopy"><div className="eyebrow">CONNECT · SHARE · EXPLORE</div><h1>HIGH <em>JYST</em></h1><h2>Your world. Your people. One global community.</h2><p>Share moments, meet new friends, and stay close to the people who make life brighter — wherever they are in the world.</p><div className="heroActions"><button className="btn gold" onClick={()=>{setAuthMode("signup");setAuthOpen(true)}}>Create your account <span>↗</span></button><a className="btn outline" href="#feed">Explore the feed</a></div><div className="trustLine"><Globe2 size={16}/> A community without borders</div></div>
      <div className="heroBadge"><Globe2 size={18}/><span><b>One world.</b><small>Countless connections.</small></span></div>
    </section>
    <div className="featureStrip"><div><ImagePlus/><b>Share your moments</b><small>Photos, videos and stories</small></div><div><Users/><b>Find your people</b><small>Build real friendships</small></div><div><MessageCircle/><b>Stay connected</b><small>Private conversations</small></div><div><ShieldCheck/><b>Your privacy matters</b><small>Safety built into the journey</small></div></div>
    <div className="pageGrid" id="feed">
      <aside className="sidebar">
        <div className="sideProfile">{profile ? <div className="avatar big">{initials(profile.display_name || profile.username)}</div> : <div className="avatar big">HJ</div>}<div><b>{profile?.display_name || profile?.username || "Welcome to HIGH JYST"}</b><small>{profile ? "Your community profile" : "Sign in to join the conversation"}</small></div></div>
        <a className="sideLink active" href="#feed"><Home/> News Feed</a><a className="sideLink" href="#people" onClick={e=>{e.preventDefault();setNotice("Friend requests and discovery are part of the next backend feature milestone.")}}><Users/> Friends & Requests</a><a className="sideLink" href="#messages" onClick={e=>{e.preventDefault();setNotice("Messaging interface is planned; see README for scope.")}}><MessageCircle/> Messages</a><a className="sideLink" href="#notifications" onClick={e=>{e.preventDefault();setNotice("Notifications are planned for the next milestone.")}}><Bell/> Notifications</a><a className="sideLink" href="#privacy" onClick={e=>{e.preventDefault();setNotice("Profile visibility controls are included in the database starter; settings UI is not yet implemented.")}}><ShieldCheck/> Privacy & Safety</a>
        <div className="sideNote"><span className="tinyGold">H</span><b>Different places.<br/>Same vibes.</b><p>Make the world feel a little smaller.</p></div>
      </aside>
      <section className="feedColumn">
        <div className="sectionHead"><div><div className="eyebrow">YOUR COMMUNITY</div><h2>News Feed</h2></div><span className="livePill"><span/> GLOBAL FEED</span></div>
        <form className="composer card" onSubmit={publish}>
          <div className="composerTop"><div className="avatar">{initials(profile?.display_name || profile?.username)}</div><textarea value={composer} onChange={e=>setComposer(e.target.value)} placeholder={profile ? "What's on your mind?" : "Log in to share a moment with the world…"} aria-label="Write a post"/></div>
          {upload && <div className="fileChip"><ImagePlus size={16}/>{upload.name}<button type="button" onClick={()=>setUpload(null)} aria-label="Remove selected file">×</button></div>}
          <div className="composerBottom"><label className="uploadBtn" htmlFor="media-upload"><ImagePlus size={18}/> Photo / Video</label><input id="media-upload" type="file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm" onChange={e=>setUpload(e.target.files?.[0] || null)} hidden/><span className="composerHint">Keep it kind. Keep it global.</span><button className="btn gold publishBtn" disabled={posting}>{posting?<LoaderCircle className="spin" size={16}/>:<Send size={15}/>} Publish</button></div>
        </form>
        {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={()=>setNotice("")}>×</button></div>}
        {loading ? <div className="loading"><LoaderCircle className="spin"/> Loading the community feed…</div> : !visiblePosts.length ? <div className="empty card"><Globe2 size={28}/><h3>Your global community starts here.</h3><p>No posts yet — be the first to share a thought, photo, or video.</p><button className="btn outline" onClick={()=>{setAuthMode(profile?"login":"signup");setAuthOpen(!profile)}}>{profile?"Create a post above":"Join HIGH JYST"}</button></div> : visiblePosts.map(post=><article className="post card" key={post.id}>
          <div className="postHeader"><div className="avatar">{initials(post.profiles?.display_name || post.profiles?.username)}</div><div className="postBy"><b>{post.profiles?.display_name || post.profiles?.username || "HIGH JYST Member"}</b><small>@{post.profiles?.username || "community"} · {timeAgo(post.created_at)}</small></div><button className="moreBtn" aria-label="More post options" onClick={()=>setNotice("Report and block actions will be enabled with the moderation tools.")}>•••</button></div>
          {post.content && <p className="postText">{post.content}</p>}
          {post.media_url && (post.media_type === "video" ? <video className="postMedia" src={post.media_url} controls preload="metadata"/> : <img className="postMedia" src={post.media_url} alt="Shared by a HIGH JYST member" loading="lazy"/>)}
          <div className="postStats"><span>✦ Community post</span><span>{post.comments?.length || 0} comments</span></div><div className="postActions"><button onClick={()=>likePost(post.id)}><Heart size={17}/> Appreciate</button><button onClick={()=>setNotice("Comment threads are planned for the next implementation milestone.")}><MessageSquare size={17}/> Comment</button><button onClick={()=>{navigator.clipboard?.writeText(window.location.href+"#feed");setNotice("Feed link copied if clipboard access is available.")}}><Send size={16}/> Share</button></div>
        </article>)}
      </section>
      <aside className="rightRail"><div className="railCard"><div className="eyebrow">THE HIGH JYST PROMISE</div><h3>Real people.<br/><em>Real connections.</em></h3><p>A place to share your world, discover different perspectives, and stay connected across borders.</p><div className="railRule"/><div className="railFeature"><Globe2/><span><b>Worldwide by design</b><small>Meet people beyond your neighbourhood.</small></span></div><div className="railFeature"><ShieldCheck/><span><b>Respect comes first</b><small>Be thoughtful. Protect your privacy.</small></span></div><button className="textLink" onClick={()=>setNotice("Community guidelines and reporting tools should be completed before public launch.")}>Community guidelines ↗</button></div><div className="railFooter">About · Privacy · Terms<br/><small>© {new Date().getFullYear()} HIGH JYST</small></div></aside>
    </div>
    <footer className="footer"><a className="brand" href="#"><span className="brandMark">H</span> HIGH JYST</a><span>Different places. Same vibes.</span><span>© {new Date().getFullYear()} HIGH JYST</span></footer>
    {authOpen && <div className="modalBackdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setAuthOpen(false)}}><section className="authModal" role="dialog" aria-modal="true" aria-labelledby="authTitle"><button className="modalClose" onClick={()=>setAuthOpen(false)} aria-label="Close">×</button><div className="brand modalBrand"><span className="brandMark">H</span> HIGH JYST</div><div className="eyebrow">YOUR WORLD AWAITS</div><h2 id="authTitle">{authMode==="signup"?"Join the global community":"Welcome back"}</h2><p>{authMode==="signup"?"Create an account and start building meaningful connections.":"Sign in to catch up with your people."}</p><form onSubmit={handleAuth} className="authForm">{authMode==="signup"&&<label>Display name<input value={displayName} onChange={e=>setDisplayName(e.target.value)} required minLength={2} placeholder="How people will know you"/></label>}<label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email" placeholder="you@example.com"/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} autoComplete={authMode==="signup"?"new-password":"current-password"} placeholder="At least 8 characters"/></label><button className="btn gold full" disabled={authBusy}>{authBusy?<LoaderCircle className="spin" size={17}/>:null}{authMode==="signup"?"Create account":"Log in"}</button></form><div className="switchAuth">{authMode==="signup"?"Already have an account?":"New to HIGH JYST?"} <button onClick={()=>setAuthMode(authMode==="signup"?"login":"signup")}>{authMode==="signup"?"Log in":"Create account"}</button></div><small className="secureNote"><ShieldCheck size={14}/> Secure authentication handled by Supabase</small></section></div>}
  </main>;
}
